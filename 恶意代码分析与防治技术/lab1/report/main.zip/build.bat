@echo off
chcp 65001 >nul
cd /d "%~dp0"

latexmk -xelatex -interaction=nonstopmode main.tex

if errorlevel 1 (
  echo.
  echo [失败] 编译出错，请查看 main.log
) else (
  echo.
  echo [完成] 已生成 main.pdf
)
pause
